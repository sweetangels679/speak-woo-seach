This folder is for plugin related files.
