This folder is for audio-samples related files.
